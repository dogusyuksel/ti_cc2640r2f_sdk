/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-K04
 */

#ifndef xdc_shelf_local__
#define xdc_shelf_local__



#endif /* xdc_shelf_local__ */ 
