/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-K04
 */

#ifndef xdc_services_spec__
#define xdc_services_spec__



#endif /* xdc_services_spec__ */ 
