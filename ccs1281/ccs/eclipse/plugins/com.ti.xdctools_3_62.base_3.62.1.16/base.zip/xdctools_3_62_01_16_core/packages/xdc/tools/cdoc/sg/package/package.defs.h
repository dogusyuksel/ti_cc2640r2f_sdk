/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-K04
 */

#ifndef xdc_tools_cdoc_sg__
#define xdc_tools_cdoc_sg__



#endif /* xdc_tools_cdoc_sg__ */ 
