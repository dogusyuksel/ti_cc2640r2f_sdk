/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-K04
 */

#ifndef xdc_shelf__
#define xdc_shelf__



#endif /* xdc_shelf__ */ 
