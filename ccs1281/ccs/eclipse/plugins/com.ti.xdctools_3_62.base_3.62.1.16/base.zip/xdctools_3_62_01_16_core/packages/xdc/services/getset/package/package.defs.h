/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-K04
 */

#ifndef xdc_services_getset__
#define xdc_services_getset__



#endif /* xdc_services_getset__ */ 
