/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-K04
 */

#ifndef xdc_tools_cdoc__
#define xdc_tools_cdoc__


/*
 * ======== module xdc.tools.cdoc.Example ========
 */

typedef struct xdc_tools_cdoc_Example_AStruct xdc_tools_cdoc_Example_AStruct;
typedef union xdc_tools_cdoc_Example_AUnion xdc_tools_cdoc_Example_AUnion;
typedef struct xdc_tools_cdoc_Example___struct__1 xdc_tools_cdoc_Example___struct__1;
typedef struct xdc_tools_cdoc_Example___struct__2 xdc_tools_cdoc_Example___struct__2;
typedef union xdc_tools_cdoc_Example___struct__3 xdc_tools_cdoc_Example___struct__3;
typedef struct xdc_tools_cdoc_Example_ACmd xdc_tools_cdoc_Example_ACmd;


#endif /* xdc_tools_cdoc__ */ 
