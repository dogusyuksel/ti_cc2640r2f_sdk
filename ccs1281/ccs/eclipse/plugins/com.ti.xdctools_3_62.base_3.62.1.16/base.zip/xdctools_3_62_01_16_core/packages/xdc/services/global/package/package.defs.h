/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-K04
 */

#ifndef xdc_services_global__
#define xdc_services_global__



#endif /* xdc_services_global__ */ 
