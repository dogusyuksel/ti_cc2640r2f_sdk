******************************************************************************
DSS Test Server
readme.txt
******************************************************************************

Please refer to the DSS Test Server documentation:
http://software-dl.ti.com/ccs/esd/documents/dss_test-server.html

