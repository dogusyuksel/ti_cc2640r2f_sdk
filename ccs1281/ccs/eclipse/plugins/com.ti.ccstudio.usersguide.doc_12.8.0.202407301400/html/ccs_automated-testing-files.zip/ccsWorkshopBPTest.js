var ccsbase_path = arguments[0].replace(/\\/g,"/");
var workspace_path = arguments[1].replace(/\\/g,"/");
var ccxml_path = arguments[2].replace(/\\/g,"/");
var out_path = arguments[3].replace(/\\/g,"/");
/* print(ccsbase_path);
print(workspace_path);
print(ccxml_path);
print(out_path); */
var exitCode=0;
// Import packages
importPackage(Packages.com.ti.debug.engine.scripting);
importPackage(Packages.com.ti.ccstudio.scripting.environment);
importPackage(Packages.java.lang);
importPackage(Packages.java.io);
try{
	// Create scripting environment object
	var script = ScriptingEnvironment.instance();
	// Configure the logger
	script.traceBegin(workspace_path + "/bp_test_out.xml", 
		ccsbase_path + "/ccs_base/scripting/examples/DebugServerExamples/DefaultStylesheet.xsl");
	script.traceSetConsoleLevel(TraceLevel.INFO);
	script.traceSetFileLevel(TraceLevel.ALL);
	// Get the debug server environment
	var debugServer = script.getServer("DebugServer.1");
	// Configure debugger with ccxml
	debugServer.setConfig(ccxml_path);
	// Open debug session
	var debugSession = debugServer.openSession(".*[Cc][Oo][Rr][Tt][Ee][Xx].*");
	// Connect to the target
	debugSession.target.connect();
	// Load program
	debugSession.memory.loadProgram(out_path);
}catch(ex){
	script.traceWrite("Breakpoint test script failed to run due to error:\n" + ex);
	java.lang.System.exit(1);
}
// Run actions
var click_left = 5;
var btn0_bp = debugSession.breakpoint.add("gpioButtonFxn0");
while(click_left>0){
	print("Please press button 0. Presses remaining: "+click_left);	
	debugSession.target.run();
	click_left = click_left - 1;
}
debugSession.target.runAsynch();
debugSession.target.halt();
debugSession.breakpoint.remove(btn0_bp);

var btn1_bp = debugSession.breakpoint.add("gpioButtonFxn1");
print("Please press button 1.");	
debugSession.target.run();
// Verify the behaviour is correct
var led_rate = debugSession.expression.evaluate("led0_on_off_useconds");
if(led_rate == 15625){
	script.traceWrite("The led frequency is correct: " + led_rate);
}else{
	script.traceWrite("The led frequency is not correct: " + led_rate + ". Should be 15625.");
	exitCode=1;
}
// Termination logic
debugSession.terminate();
debugServer.stop();
script.traceEnd(); 
java.lang.System.exit(exitCode);
 