var ccsbase_path = arguments[0].replace(/\\/g,"/");
var workspace_path = arguments[1].replace(/\\/g,"/");
var ccxml_path = arguments[2].replace(/\\/g,"/");
var out_path = arguments[3].replace(/\\/g,"/");
/* print(ccsbase_path);
print(workspace_path);
print(ccxml_path);
print(out_path); */
var exitCode=0;
// Import packages
importPackage(Packages.com.ti.debug.engine.scripting);
importPackage(Packages.com.ti.ccstudio.scripting.environment);
importPackage(Packages.java.lang);
importPackage(Packages.java.io);
try{
	// Create scripting environment object
	var script = ScriptingEnvironment.instance();
	// Configure the logger
	script.traceBegin(workspace_path + "/wp_test_out.xml", 
		ccsbase_path + "/ccs_base/scripting/examples/DebugServerExamples/DefaultStylesheet.xsl");
	script.traceSetConsoleLevel(TraceLevel.INFO);
	script.traceSetFileLevel(TraceLevel.ALL);
	// Get the debug server environment
	var debugServer = script.getServer("DebugServer.1");
	// Configure debugger with ccxml
	debugServer.setConfig(ccxml_path);
	// Open debug session
	var debugSession = debugServer.openSession(".*[Cc][Oo][Rr][Tt][Ee][Xx].*");
	// Connect to the target
	debugSession.target.connect();
	// Load program
	debugSession.memory.loadProgram(out_path);
}catch(ex){
	script.traceWrite("Breakpoint test script failed to run due to error:\n" + ex);
	java.lang.System.exit(1);
}
// Run actions
var led_bp_properties = debugSession.breakpoint.createProperties(1);
led_bp_properties.setString("Hardware Configuration.Type", "Watchpoint");
led_bp_properties.setString("Hardware Configuration.Type.Location", "&led0_on_off_useconds");
led_bp_properties.setString("Hardware Configuration.Type.Memory", "Write");
led_bp_properties.setString("Hardware Configuration.Type.With Data", "Yes");
led_bp_properties.setNumeric("Hardware Configuration.Type.With Data.Data Value", "0x3d09");
// led_bp_properties.printProperties();
var led_bp = debugSession.breakpoint.add(led_bp_properties);
print("Please press button 0 several times.");	
debugSession.target.run();
var led_rate = debugSession.expression.evaluate("led0_on_off_useconds");
if(led_rate == 15625){
	script.traceWrite("The led frequency is correct: " + led_rate);
}else{
	script.traceWrite("The led frequency is not correct: " + led_rate + ". Should be 15625.");
	exitCode=1;
}
// Termination logic
debugSession.terminate();
debugServer.stop();
script.traceEnd(); 
java.lang.System.exit(exitCode);
 