var ccsbase_path = arguments[0].replace(/\\/g,"/");
var workspace_path = arguments[1].replace(/\\/g,"/");
var ccxml_path = arguments[2].replace(/\\/g,"/");
var out_path = arguments[3].replace(/\\/g,"/");
/* print(ccsbase_path);
print(workspace_path);
print(ccxml_path);
print(out_path); */
var exitCode=0;
// Import packages
importPackage(Packages.com.ti.debug.engine.scripting);
importPackage(Packages.com.ti.ccstudio.scripting.environment);
importPackage(Packages.java.lang);
importPackage(Packages.java.io);
try{
	// Create scripting environment object
	var script = ScriptingEnvironment.instance();
	// Configure the logger
	script.traceBegin(workspace_path + "/basic_test_out.xml", 
		ccsbase_path + "/ccs_base/scripting/examples/DebugServerExamples/DefaultStylesheet.xsl");
	script.traceSetConsoleLevel(TraceLevel.INFO);
	script.traceSetFileLevel(TraceLevel.ALL);
	// Get the debug server environment
	var debugServer = script.getServer("DebugServer.1");
	// Configure debugger with ccxml
	debugServer.setConfig(ccxml_path);
	// Open debug session
	var debugSession = debugServer.openSession(".*[Cc][Oo][Rr][Tt][Ee][Xx].*");
	// Connect to the target
	debugSession.target.connect();
	// Load Program
	debugSession.memory.loadProgram(out_path);
}catch(ex){
	script.traceWrite("Basic test script failed to run due to error:\n" + ex);
	java.lang.System.exit(1);
}

// Run actions
debugSession.target.runAsynch();
// Verify the behaviour is correct
var stdin = new BufferedReader(new InputStreamReader(System['in']));
while(true){
	print("Is LED blinking? y/n");
	var answer=stdin.readLine();
	if(answer.equals("y")){
		script.traceWrite("The example project runs correctly.");
		break;	
	}
	if(answer.equals("n")){
		script.traceWrite("The example project is broken, the LED is not blinking.");
		exitCode=1;
		break;	
	}
}
// Termination logic
debugSession.terminate();
debugServer.stop();
script.traceEnd(); 
java.lang.System.exit(exitCode);
 