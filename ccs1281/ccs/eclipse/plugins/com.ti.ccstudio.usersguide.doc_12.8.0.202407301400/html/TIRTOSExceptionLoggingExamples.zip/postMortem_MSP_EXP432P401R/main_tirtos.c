/*
 * Copyright (c) 2016-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,

 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== main_tirtos.c ========
 */
#include <stdint.h>

/* RTOS Header files */
#include <xdc/std.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Log.h>
#include <xdc/runtime/Diags.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/uia/runtime/UIAPacket.h>
#include <ti/uia/loggers/LoggerMin.h>
#include <ti/uia/events/UIABenchmark.h>

/* Driver header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/NVS.h>

/* Example/Board Header files */
#include "Board.h"

/* Stack size in bytes */
#define THREADSTACKSIZE    768


/*
 *  ======== gpioButtonFxn0 ========
 *  GPIO Callback to cause an exception
 */
void gpioButtonFxn0(uint_least8_t index)
{
    asm("        .word 0x4567f123  "); // undefine instruction!
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Turn logging on
 */
void gpioButtonFxn1(uint_least8_t index)
{    
    GPIO_write(Board_GPIO_LED1, Board_GPIO_LED_ON);

    /* Enable the applications USER1 and ANALYSIS bitmasks */
    Diags_setMask("xdc.runtime.Main+1Z");
}

/*
 *  ======== task1 ========
 */
Void task1(UArg arg0, UArg arg1)
{
    while(1) {
        Log_write1(UIABenchmark_start, (IArg)"task1 sleep time");
        Task_sleep(3);
        Log_write1(UIABenchmark_stop, (IArg)"task1 sleep time");
    }
}

/*
 *  ======== task2 ========
 */
Void task2(UArg arg0, UArg arg1)
{
    int i;
    volatile int dummy;
    int counter = 0;
    
    while(1) {
        Log_print2(Diags_USER1, "counter1 = %d (0x%x)", counter, counter);
        counter++;
        
        /* Burn some CPU to simulate some real action */
        for(i = 0; i < 1000; i++) {
            dummy *= i;
        }
        Task_sleep(6);
    }
}

/*
 *  ======== main ========
 */
int main(void)
{
    Task_Handle taskHandle0, taskHandle1;
    Task_Params taskParams;

    /* Call driver init functions */
    Board_initGeneral();

    /* Initialize the GPIO and NVS drivers since multiple threads are using it */
    GPIO_init();
    NVS_init();

    GPIO_setCallback(Board_GPIO_BUTTON0, gpioButtonFxn0);
    GPIO_setCallback(Board_GPIO_BUTTON1, gpioButtonFxn1);
    
    GPIO_enableInt(Board_GPIO_BUTTON0);
    GPIO_enableInt(Board_GPIO_BUTTON1);
    
    GPIO_write(Board_GPIO_LED0, Board_GPIO_LED_OFF);
    GPIO_write(Board_GPIO_LED1, Board_GPIO_LED_OFF);

    /* Create the Tasks that do some logging */
    Task_Params_init(&taskParams);
    taskParams.stackSize = THREADSTACKSIZE;
    taskParams.priority = 1;
    taskHandle0 = Task_create((Task_FuncPtr)task1, &taskParams, Error_IGNORE);
    if (taskHandle0 == NULL) {
        System_printf("Failed to create task1\n");
    }

    taskParams.priority = 2;
    taskHandle1 = Task_create((Task_FuncPtr)task2, &taskParams, Error_IGNORE);
    if (taskHandle1 == NULL) {
        System_printf("Failed to create task2\n");
    }


    /* Start the TI-RTOS scheduler */
    BIOS_start();

    return (0);
}

#define LOGBUFFERSIZE    2048
#define UIAPACKETOFFSET    16
char buffer[LOGBUFFERSIZE];
/*
 *  ======== myExceptionHandler ========
 *  My exception handler which writes the log buffes to flash memory
 */
Void myExceptionHandler(UInt *excStack, UInt lr)
{
    size_t copiedLen;
    NVS_Handle nvsHandle;
    NVS_Attrs regionAttrs;
    Bool rc;

    GPIO_write(Board_GPIO_LED0, Board_GPIO_LED_ON);

    nvsHandle = NVS_open(Board_NVS0, NULL);
    NVS_getAttrs(nvsHandle, &regionAttrs);
    NVS_erase(nvsHandle, 0, regionAttrs.regionSize);

    /* LoggerMin is a singleton, so we can use NULL here */
    rc = ti_uia_loggers_LoggerMin_getContents(NULL, &(buffer[UIAPACKETOFFSET]),
                                              LOGBUFFERSIZE - UIAPACKETOFFSET,
                                              &copiedLen);
    if (rc == TRUE) {

        UIAPacket_setEventLengthFast((UIAPacket_Hdr *)buffer,
                                      copiedLen + UIAPACKETOFFSET);
        UIAPacket_setSequenceCounts((UIAPacket_Hdr *)buffer, 1, 0);
        UIAPacket_setLoggerInstanceId((UIAPacket_Hdr *)buffer, 1);
        UIAPacket_setLoggerModuleId((UIAPacket_Hdr *)buffer,
                                    LoggerMin_Module_id());
        UIAPacket_setSenderAdrs((UIAPacket_Hdr *)buffer, 0);
        UIAPacket_setDestAdrs((UIAPacket_Hdr *)buffer, UIAPacket_HOST);


        if (copiedLen != 0) {
            NVS_write(nvsHandle, 0, buffer, copiedLen + UIAPACKETOFFSET, 0);
        }
    }
    
    while(1);
}
